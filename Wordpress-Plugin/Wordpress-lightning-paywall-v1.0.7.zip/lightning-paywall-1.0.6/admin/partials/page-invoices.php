<section class="section">
	<h1>Invoices</h1>
	<div class="section scroll">
		<table class='section table'>
			<thead>
				<tr>
					<th>Date</th>
					<th>Content title</th>
					<th>Status</th>
					<th>Amount</th>
					<th>Currency</th>
					<th>Invoice id</th>
				</tr>
			</thead>
			<tbody class="section invoices">

			</tbody>
		</table>
	</div>
</section>