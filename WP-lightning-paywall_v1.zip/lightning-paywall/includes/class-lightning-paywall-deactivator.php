<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://academweb.com/contacts
 * @since      1.0.0
 *
 * @package    Lightning_Paywall
 * @subpackage Lightning_Paywall/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Lightning_Paywall
 * @subpackage Lightning_Paywall/includes
 * @author     Academ Web Solutions <contact@academweb.com>
 */
class Lightning_Paywall_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 */
	public static function deactivate() {

	}

}
