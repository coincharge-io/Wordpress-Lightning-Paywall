<?php

$post_types            = Lightning_Paywall_Admin::get_allowed_post_types();
$enabled_post_types    = get_option( 'lnpw_enabled_post_types' );
$used_currency         = get_option( 'lnpw_currency' );
$supported_currencies  = Lightning_Paywall_Admin::CURRENCIES;
$default_price         = get_option( 'lnpw_default_price' );
$default_duration      = get_option( 'lnpw_default_duration' );
$default_duration_type = get_option( 'lnpw_default_duration_type' );
$supported_durations   = Lightning_Paywall_Admin::DURATIONS;

$btcpay_server_url = get_option( 'lnpw_btcpay_server_url' );

$btcpay_auth_key = get_option( 'lnpw_btcpay_auth_key' );
$btcpay_status   = get_option( 'lnpw_btcpay_status' );

?>
<div class="wrap">
    <h1>Lightning Paywall Settings</h1>

    <div style="margin-top: 25px;">

        <form method="POST" action="options.php">
			<?php settings_fields( 'lnpw_general_settings' ); ?>

            <div>
                <label for="lnpw_enabled_post_types">Enabled on</label>

				<?php foreach ( $post_types as $post_type ) : ?>
                    <span style="margin-left: 15px; text-transform: capitalize">
                                                <label style="line-height: 1" for="lnpw_enabled_<?= $post_type ?>"><?= $post_type ?></label>

                        <input style="margin: 0" type="checkbox" name="lnpw_enabled_post_types[]" id="lnpw_enabled_<?= $post_type ?>" value="<?= $post_type ?>" <?= in_array( $post_type, $enabled_post_types ) ? 'checked' : ''; ?>>
                    </span>
				<?php endforeach; ?>
            </div>

            <div style="margin-top: 25px;">

                <label for="lnpw_default_price">Default price</label>
                <input required type="number" placeholder="Default Price" name="lnpw_default_price" id="lnpw_default_price" value="<?= $default_price ?>">

                <select required name="lnpw_currency" id="lnpw_currency">
                    <option disabled value="">Select currency</option>
					<?php foreach ( $supported_currencies as $currency ) : ?>
                        <option <?= $used_currency === $currency ? 'selected' : ''; ?> value="<?= $currency; ?>">
							<?= $currency; ?>
                        </option>
					<?php endforeach; ?>
                </select>

            </div>

            <div style="margin-top: 25px;">

                <label for="lnpw_default_duration">Default duration</label>
                <input required type="number" min="1" placeholder="Default Access Duration" name="lnpw_default_duration" id="lnpw_default_duration" value="<?= $default_duration ?>">

                <select required name="lnpw_default_duration_type">
                    <option disabled value="">Select duration type</option>
					<?php foreach ( $supported_durations as $duration ) : ?>
                        <option <?php selected( $default_duration_type, $duration ); ?> value="<?= $duration ?>"><?= $duration ?></option>
					<?php endforeach; ?>
                </select>
            </div>

            <div style="margin-top: 25px;">
                <label>BTCPay Server Url</label>

                <input type="url" placeholder="BTCPay Server Url" name="lnpw_btcpay_server_url" id="lnpw_btcpay_server_url" value="<?= $btcpay_server_url ?>">
            </div>

            <div style="margin-top: 25px;">
                <label for="lnpw_btcpay_auth_key">BTCPay Server Auth Key</label>
                <input required type="password" placeholder="Auth Key" name="lnpw_btcpay_auth_key" id="lnpw_btcpay_auth_key" value="<?= $btcpay_auth_key ?>">
            </div>

            <div style="margin-top: 25px;">
				<?php if ( $btcpay_status ) : ?>
                    <p style="font-weight: bold; color: green;">BTCPAY SERVER CONNECTED</p>
				<?php else: ?>
                    <p style="font-weight: bold; color: red;">BTCPAY SERVER NOT CONNECTED</p>
				<?php endif; ?>
            </div>

            <div style="display: inline-block; margin-top: 25px;">
                <button class="button button-primary" type="submit">Save</button>
            </div>
        </form>

    </div>

</div>