<div class="lnpw_pay">
    <div class="lnpw_pay__content">
        <h3>For access to content first pay</h3>
        <p>
			<?= Lightning_Paywall_Public::get_post_price_string() ?>
        </p>
    </div>
    <div class="lnpw_pay__footer">
        <button type="button" id="lnpw_pay_button" data-post_id="<?= get_the_ID(); ?>">Pay</button>
    </div>
</div>