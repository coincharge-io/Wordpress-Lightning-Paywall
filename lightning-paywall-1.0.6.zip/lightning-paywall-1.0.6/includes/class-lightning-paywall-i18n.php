<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://academweb.com/contacts
 * @since      1.0.0
 *
 * @package    Lightning_Paywall
 * @subpackage Lightning_Paywall/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Lightning_Paywall
 * @subpackage Lightning_Paywall/includes
 * @author     Academ Web Solutions <contact@academweb.com>
 */
class Lightning_Paywall_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'lightning-paywall',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}


}
