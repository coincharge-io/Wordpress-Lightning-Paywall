<?php

/**
 * Fired during plugin activation
 *
 * @link       https://academweb.com/contacts
 * @since      1.0.0
 *
 * @package    Lightning_Paywall
 * @subpackage Lightning_Paywall/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Lightning_Paywall
 * @subpackage Lightning_Paywall/includes
 * @author     Academ Web Solutions <contact@academweb.com>
 */
class Lightning_Paywall_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 */
	public static function activate() {

	}

}
