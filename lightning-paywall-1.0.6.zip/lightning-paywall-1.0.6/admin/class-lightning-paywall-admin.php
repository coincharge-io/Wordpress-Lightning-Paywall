<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Lightning_Paywall
 * @subpackage Lightning_Paywall/admin
 * @author     Academ Web Solutions <contact@academweb.com>
 */
class Lightning_Paywall_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @access   private
	 * @var      string $plugin_name The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @access   private
	 * @var      string $version The current version of this plugin.
	 */
	private $version;

	/**
	 *
	 */
	const DURATIONS = [
		'minutes',
		'hours',
		'weeks',
		'months',
		'years',
	];

	/**
	 *
	 */
	const CURRENCIES = [
		'SATS',
		'BTC',
		'USD',
		'EUR',
	];

	/**
	 * Initialize the class and set its properties.
	 *
	 * @param  string  $plugin_name  The name of this plugin.
	 * @param  string  $version  The version of this plugin.
	 *
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 */
	public function enqueue_styles() {

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/lightning-paywall-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 */
	public function enqueue_scripts() {

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/lightning-paywall-admin.js', array( 'jquery' ), $this->version, false );

	}

	public function register_post_types() {

		register_post_type( 'lnpw_order', [
			'label'               => 'LP Orders',
			'public'              => true,
			'publicly_queryable'  => false,
			'exclude_from_search' => true,
			'show_ui'             => true,
			'show_in_nav_menus'   => false,
			'show_in_menu'        => false,
			'show_in_admin_bar'   => false,
			'show_in_rest'        => false,
			'rest_base'           => null,
			'menu_position'       => null,
			'menu_icon'           => null,
			'hierarchical'        => false,
			'supports'            => [ 'title', 'custom-fields' ],
			'taxonomies'          => [],
			'has_archive'         => false,
			'rewrite'             => true,
			'query_var'           => true,
		] );

	}

	/**
	 * Add admin menu pages
	 */
	public function add_menu_pages() {

		add_menu_page( 'Lightning Paywall', 'Lightning Paywall', 'manage_options', 'lnpw_general_settings', array( $this, 'render_general_settings_page' ), 'dashicons-tickets' );

	}

	/**
	 *
	 */
	public function register_settings() {

		register_setting( 'lnpw_general_settings', 'lnpw_enabled_post_types', array( 'type' => 'array', 'default' => array( 'post' ) ) );
		register_setting( 'lnpw_general_settings', 'lnpw_currency', array( 'type' => 'string', 'default' => 'SATS' ) );
		register_setting( 'lnpw_general_settings', 'lnpw_default_price', array( 'type' => 'number', 'default' => 10 ) );
		register_setting( 'lnpw_general_settings', 'lnpw_default_duration', array( 'type' => 'integer', 'default' => 24 ) );
		register_setting( 'lnpw_general_settings', 'lnpw_default_duration_type', array( 'type' => 'string', 'default' => 'hours' ) );

		register_setting( 'lnpw_general_settings', 'lnpw_btcpay_server_url', array( 'type' => 'string', 'sanitize_callback' => array( $this, 'sanitize_btcpay_server_url' ) ) );
		register_setting( 'lnpw_general_settings', 'lnpw_btcpay_auth_key', array( 'type' => 'string', 'sanitize_callback' => array( $this, 'sanitize_btcpay_auth_key' ) ) );

	}

	public function sanitize_btcpay_server_url( $value ) {

		$value = sanitize_text_field( $value );

		return trim( $value, '/' );

	}

	public function sanitize_btcpay_auth_key( $value ) {

		$value = sanitize_text_field( $value );

		if ( strpos( $value, 'Basic' ) !== false ) {
			$value = substr( $value, strpos( $value, 'Basic' ) + 6 );
		}

		return $value;

	}

	public function ajax_check_btcpay_api_work() {

		if ( empty( $_POST[ 'auth_key' ] ) || empty( $_POST[ 'server_url' ] ) ) {
			wp_send_json_error( [ 'message' => 'Auth Key & Server Url required' ] );
		}

		$auth_key   = sanitize_text_field( $_POST[ 'auth_key' ] );
		$server_url = sanitize_text_field( $_POST[ 'server_url' ] );

		$args = array(
			'headers'     => array(
				'Authorization' => 'Basic ' . $auth_key,
				'Content-Type'  => 'application/json',
			),
			'body'        => json_encode( [] ),
			'method'      => 'GET',
			'timeout'     => 30,
			'data_format' => 'body',
		);

		$response = wp_remote_request( $server_url . '/invoices', $args );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( [ 'message' => 'The url is not configurated correctly!'] );
		}

		if ( $response[ 'response' ][ 'code' ] === 200) {
			wp_send_json_success(['message' => 'You are connected!']);
		} else {
			wp_send_json_error( [ 'message' => ($response[ 'response' ][ 'code' ] === 401? 'Improper auth key!' :'')] );
		}

	}

	/**
	 *
	 */
	public function add_meta_boxes() {

		if ( get_option( 'lnpw_enabled_post_types' ) ) {
			add_meta_box( 'lnpw_post_settings', 'Lightning Paywall Settings', array( $this, 'render_post_settings_meta_box' ), get_option( 'lnpw_enabled_post_types' ) );
		}

	}

	/**
	 * Render General Settings page
	 */
	public function render_general_settings_page() {
		include 'partials/page-general-settings.php';
	}

	/**
	 * @param  WP_Post  $post
	 * @param  array  $meta
	 */
	public function render_post_settings_meta_box( $post, $meta ) {

		wp_nonce_field( plugin_basename( __FILE__ ), 'lnpw_post_meta_box_nonce' );

		include 'partials/meta-box-post-settings.php';

	}

	/**
	 * @param  int  $post_id
	 */
	public function save_post_settings_meta_box( $post_id ) {

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! isset( $_POST[ 'lnpw_post_meta_box_nonce' ] ) || ! wp_verify_nonce( $_POST[ 'lnpw_post_meta_box_nonce' ], plugin_basename( __FILE__ ) ) ) {
			return;
		}

		if ( ! empty( $_POST[ 'lnpw_enabled' ] ) ) {
			update_post_meta( $post_id, 'lnpw_enabled', sanitize_text_field( $_POST[ 'lnpw_enabled' ] ) );
		} else {
			delete_post_meta( $post_id, 'lnpw_enabled' );
		}

		if ( ! empty( $_POST[ 'lnpw_price' ] ) ) {
			update_post_meta( $post_id, 'lnpw_price', sanitize_text_field( $_POST[ 'lnpw_price' ] ) );
		} else {
			delete_post_meta( $post_id, 'lnpw_price' );
		}

		if ( ! empty( $_POST[ 'lnpw_duration' ] ) ) {
			update_post_meta( $post_id, 'lnpw_duration', sanitize_text_field( $_POST[ 'lnpw_duration' ] ) );
		} else {
			delete_post_meta( $post_id, 'lnpw_duration' );
		}

		if ( ! empty( $_POST[ 'lnpw_duration_type' ] ) ) {
			update_post_meta( $post_id, 'lnpw_duration_type', sanitize_text_field( $_POST[ 'lnpw_duration_type' ] ) );
		} else {
			delete_post_meta( $post_id, 'lnpw_duration_type' );
		}

	}

	/**
	 * @throws Exception
	 */
	public function load_vc_widgets() {

		vc_map( array(
			'name'        => 'LP Start Paid Content',
			'base'        => 'lnpw_start_content',
			'description' => 'Start area of paid content',
			'category'    => 'Content',
			'params'      => array(
				array(
					'type'        => 'checkbox',
					'heading'     => 'Enable payment block',
					'param_name'  => 'pay_block',
					'value'       => false,
					'description' => 'Show payment block instead of content',
				),
			),
		) );

		vc_map( array(
			'name'        => 'LP End Paid Content',
			'base'        => 'lnpw_end_content',
			'description' => 'End area of paid content',
			'category'    => 'Content',
			'params'      => array(),
		) );

		vc_map( array(
			'name'        => 'LP Pay Widget',
			'base'        => 'lnpw_pay_block',
			'description' => 'Show Payment Widget',
			'category'    => 'Content',
			'params'      => array(),
		) );

	}

	public function load_elementor_widgets() {

		require_once 'elementor/class-start-content-widget.php';
		require_once 'elementor/class-end-content-widget.php';
		require_once 'elementor/class-pay-block-widget.php';

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Elementor_LNPW_Start_Content_Widget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Elementor_LNPW_End_Content_Widget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Elementor_LNPW_Pay_Block_Widget() );

	}

	/**
	 * @return string[]|WP_Post_Type[]
	 */
	public static function get_allowed_post_types() {

		$post_types           = get_post_types( [ 'publicly_queryable' => true ] );
		$post_types[ 'page' ] = 'page';

		$blocked_post_types = [
			'elementor_library',
			'e-landing-page',
			'attachment',
		];

		foreach ( $blocked_post_types as $post_type ) {
			if ( isset( $post_types[ $post_type ] ) ) {
				unset( $post_types[ $post_type ] );
			}
		}

		return $post_types;

	}


}
