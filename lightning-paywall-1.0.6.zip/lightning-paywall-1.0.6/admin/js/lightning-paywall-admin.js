(function ($) {
    'use strict';

    $(document).ready(function () {

        $('#lnpw_btcpay_check_status').click(function () {

            $('.lnpw_btcpay_status').hide(500);

            $.ajax({
                url: '/wp-admin/admin-ajax.php',
                method: 'POST',
                data: {
                    action: 'lnpw_check_btcpay_api_work',
                    auth_key: $('#lnpw_btcpay_auth_key').val(),
                    server_url: $('#lnpw_btcpay_server_url').val()
                },
                success: function (response) {
                    if (response.success) {
                        $('#lnpw_btcpay_status_success').fadeIn(500);
                    } else {
                        $('#lnpw_btcpay_status_error').html(response.data.message).fadeIn(500);
                    }
                }
            });

        });

    });

})(jQuery);
